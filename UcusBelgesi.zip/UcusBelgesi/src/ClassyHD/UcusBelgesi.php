<?php

namespace ClassyHD;

use onebone\economyapi\EconomyAPI;
use pocketmine\plugin\PluginBase;
use pocketmine\player\Player;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\form\Form;
use pocketmine\scheduler\Task;

class UcusBelgesi extends PluginBase {

    public function onEnable(): void {
        $this->getLogger()->info("§aUcusBelgesi eklentisi aktif!");
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
        if (!$sender instanceof Player) {
            $sender->sendMessage("§cBu komutu sadece oyunda kullanabilirsin.");
            return true;
        }

        if ($command->getName() === "ucusbelgesi") {
            $this->showForm($sender);
            return true;
        }

        return false;
    }

    public function showForm(Player $player): void {
        $form = new class($player, $this) implements Form {
            private Player $player;
            private UcusBelgesi $plugin;

            public function __construct(Player $player, UcusBelgesi $plugin) {
                $this->player = $player;
                $this->plugin = $plugin;
            }

            public function jsonSerialize(): mixed {
                return [
                    "type" => "custom_form",
                    "title" => "Uçuş Belgesi Satın Al",
                    "content" => [
                        [
                            "type" => "label",
                            "text" => "§bKaç dakikalık uçuş belgesi almak istersin?\n§7Dakika başına fiyat: §61300TL\n§cMax: 30 dakika"
                        ],
                        [
                            "type" => "input",
                            "text" => "§fDakika giriniz (1-30):",
                            "placeholder" => "örn. 10"
                        ]
                    ]
                ];
            }

            public function handleResponse(Player $player, $data): void {
                if ($data === null) {
                    $player->sendMessage("§cİşlem iptal edildi.");
                    return;
                }

                $dakika = (int)$data[1];
                $fiyat = $dakika * 1300;

                if ($dakika < 1 || $dakika > 30) {
                    $player->sendMessage("§cGeçerli bir dakika girin! (1-30)");
                    return;
                }

                $economy = EconomyAPI::getInstance();
                $para = $economy->myMoney($player);

                if ($para < $fiyat) {
                    $player->sendMessage("§cYeterli paran yok! Gerekli: §f{$fiyat}§c, Senin paran: §f{$para}");
                    return;
                }

                // Para düşülür ve uçuş izni verilir
                $economy->reduceMoney($player, $fiyat);
                $player->setAllowFlight(true);
                $player->sendMessage("§a{$dakika} dakikalık uçuş belgesi satın aldın! §7(-{$fiyat} TL)");
                $player->sendMessage("§bUçuş hakkı aktif oldu, §e{$dakika} dakika§b sürecek.");

                // Süre dolunca uçuş kapatılır
                $this->plugin->getScheduler()->scheduleDelayedTask(
                    new class($player) extends Task {
                        private Player $player;

                        public function __construct(Player $player) {
                            $this->player = $player;
                        }

                        public function onRun(): void {
                            if ($this->player->isOnline()) {
                                $this->player->setAllowFlight(false);
                                $this->player->setFlying(false);
                                $this->player->sendMessage("§cUçuş süren doldu. Artık uçamazsın.");
                            }
                        }
                    },
                    $dakika * 60 * 20 // Tick cinsinden: dakika * 60 saniye * 20
                );
            }
        };

        $player->sendForm($form);
    }
}